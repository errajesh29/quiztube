test('Our first test', ()=>{
//throw new Error('something failed');
});

test('Should return total notes', ()=>{
    const res = 0;
    expect(result).toBe(1);
});