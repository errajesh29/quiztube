

var quizQuestions = [
  {
      question: "What is your spirit animal ? ",
      answers: [
          {
              type: "Stark",
              content: "Wolf"
              
          },
  
 
 
          {
              type: "Lannister",
              content: "Lion"
          },
          {
              type: "Targaryen",
              content: "Dragon"
          }
      ]
  },
  {
      question: "What do you value most ? ",
      answers: [
          {
              type: "Stark",
              content: "Loyalty"
          },
          {
              type: "Lannister",
              content: "Money"
          },
          {
              type: "Targaryen",
              content: "Power"
          }
      ]
  },
  {
      question: "Who's your favorite family member ?",
      answers: [
          {
              type: "Stark",
              content: "My Parent"
          },
          {
              type: "Lannister",
              content: "My Sibling"
          },
          {
              type: "Targaryen",
              content: "My Grandparent"
          }
      ]
  },
  {
      question: "Choose an element",
      answers: [
          {
              type: "Stark",
              content: "Water"
          },
          {
              type: "Lannister",
              content: "Air"
          },
          {
              type: "Targaryen",
              content: "Fire"
          }
      ]
  },
  {
      question: " Which Castle would you live in ? ",
      answers: [
          {
              type: "Stark",
              content: "Winterfell"
          },
          {
              type: "Lannister",
              content: "Casterly Rock"
          },
          {
              type: "Targaryen",
              content: "DragonStone"
          }
      ]
  }
];
 
export default quizQuestions;
